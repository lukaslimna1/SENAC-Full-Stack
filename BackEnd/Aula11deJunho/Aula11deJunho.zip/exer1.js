function receba(mensagem) {
    console.log('Hello World');   
}

receba()