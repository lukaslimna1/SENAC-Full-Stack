function receba(mensagem) {
    console.log(mensagem);   
}

receba('Já acabou Jessica')