function ola () {
    
    mensagem = "Mensagem Padrão"
    return mensagem;
}


var mensagem = ola();
console.log(mensagem);