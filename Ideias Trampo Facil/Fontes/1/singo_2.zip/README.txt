By installing or using this font, you are agree to the Product Usage Agreement:

- Here is the link to DOWNLOAD FULL VERSION AND COMMERCIAL USE: https://www.creativefabrica.com/product/singo/ref/480192/
- For Corporate use you have to purchase Corporate license: at ardana619@gmail.com
- Our another awesome products visit here: https://www.creativefabrica.com/designer/bluetype/ref/480192/
- If you need a custom license please contact us: at ardana619@gmail.com
- Any donation are very appreciated. Paypal account for donation: https://paypal.me/bpkedypurwanto
- Follow our Instagram for update : @ardana619
